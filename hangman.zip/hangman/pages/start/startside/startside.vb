﻿Public Class startside
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        '    Dim hovedside As New Form2
        '    Me.Hide()
        '    hovedside.Show()


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackgroundImage = Image.FromFile("..\..\Resources\14682028_10154691281833395_241364061752557834_o.jpg")
    End Sub
End Class
