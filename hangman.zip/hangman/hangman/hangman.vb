﻿Public Class hangman

    Dim word = hovedSide.theWord
    'henter ut hvilket ord som ble valgt fra hovedsiden.

    Dim forsok As Integer = 10
    'integer for antall forsøk, denne reduserer vi med 1 når noen får feil lengre nede i koden.

    Dim riktig As Integer = word.length
    'brukes for å definere hvor mange riktige det er i ordet.

    Dim antallriktige As Integer = 0
    'brukes for å definere win lengre nede.

    Dim dead As Boolean = False
    'settes som true ved tap. antall forsøk lik 0.

    Dim ismylettertrue As Boolean = False
    'brukes får å vite når de har riktig.

    Dim bildeCounter As Integer = 2
    '2 fordi bilde navnene begynner på 2

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'når de taper vises ordet som var riktig. her resettes labelen.
        taptOrdet.Text = ""
        'borderless/fullscreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.BackgroundImage = Image.FromFile("..\..\Resources\bilde1.jpg")

        'grafiske elemnter i form av buttons blir deaktivert. Labels blir tømt.
        brukteBokstaver.Text = String.Empty
        fyllBoks.Enabled = False
        brukteBoks.Enabled = False
        alfabetBoks.Enabled = False

        ordet.Text = String.Empty
        streker.Text = String.Empty

        ' Her lages det streker i en label for antall bokstaver i ordet, og spaces for antall bokstaver i samme ord.
        For i = 0 To word.length - 1
            ordet.Text += " "
            streker.Text += "-"
        Next
    End Sub


    'Her er prosedyren som tar for seg hele skjekk prosessen for å se hvilken bokstav som er riktig.
    Sub testPress(check As String)   'check blir ka den de trykker på. Se buttons.click lengre nede. Dette kunne bli kalt hva som helst, bob eller noe.

        For i = 0 To word.length - 1
            If check = word.Substring(i, 1).toUpper Then
                'substring skjekker 0,1 - 1,1  2,1  3,1  4,1osv. altså en bokstav av gangen. i er start og 1 er slutt.
                'så hvis en bokstav er riktig fjernes mellomrommet i labelenen, og så blir det satt in "check" som er tekstverdien av knappen som blir trykt på. Se funksjon lengre nede.
                Me.ordet.Text = ordet.Text.Remove(i, 1)      '
                Me.ordet.Text = ordet.Text.Insert(i, check)  '


                'settes til true slik at prosedyren ignorerer neste if condition.
                ismylettertrue = True
                'counter for antall riktige
                antallriktige += 1
            End If

        Next

        'Hvis de har feil bokstav, skal bruktebostaver stringen bli lik seg selv (altså ingenting ved første) + check (den bokstaven de trykte på) og et mellomrom
        'for hver feil, sett antall forsøk 1 mindre. når forsøk har nådd 0, settes dead til true.
        If ismylettertrue = False Then
            brukteBokstaver.Text += check & " "
            forsok -= 1
            If forsok = 0 Then
                dead = True
            End If

            'bildene heter 2.png, 3.png osv så da kan vi bruke bildeCounter, slik at bildene blir oppdatert for hver feil de får.
            PictureBox1.Image = Image.FromFile("..\..\Resources\" & bildeCounter & ".png")

            'så lenge de ikke har tapt, øk bildeCounter ved feil.
            If forsok <> 0 Then
                bildeCounter += 1

            End If

        End If

        'reset ismylettertrue slik at prosedyren kan brukes på nytt til neste gang de trykker.
        ismylettertrue = False

        'settes en timer på 1,5 sec for å få litt pause når de vinner før det går til neste form.
        If antallriktige = riktig Then
            Timer1.Enabled = True
            Timer1.Interval = 1500
        End If
    End Sub

    'Når hvilken som helst knapp trykkes, altså alle alfabetknappene
    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button9.Click, Button8.Click, Button7.Click, Button6.Click, Button5.Click, Button4.Click, fyllBoks.Click, Button3.Click, Button29.Click, Button28.Click, Button27.Click, Button26.Click, Button25.Click, Button24.Click, Button23.Click, Button22.Click, Button21.Click, Button20.Click, Button2.Click, Button19.Click, Button18.Click, Button17.Click, Button16.Click, Button15.Click, Button14.Click, Button13.Click, Button12.Click, Button11.Click, Button10.Click, Button1.Click
        testPress((DirectCast(sender, Button).Text))    'DirectCast(sender, Button) er koden for å finne ut hvilken knapp som ble trykt på, slik at det bare skjer med den respektive knappen og ikke alle.
        DirectCast(sender, Button).Enabled = False      'skrur av knappen som ble trykt på.

        If dead = True Then 'antall forsøk er lik 0
            taptOrdet.Text = word
            ' settes en timer på 1.5 sec før de taper
            Timer2.Enabled = True
            Timer2.Interval = 1500
        End If
    End Sub

    'når man vinner
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Close()
        theEnd.Show()
    End Sub

    'når man taper
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Me.Close()
        loss.Show()
    End Sub

    'hvis du vil avslutte
    Private Sub Button30_Click_1(sender As Object, e As EventArgs) Handles Button30.Click
        Application.Exit()
    End Sub

    'hvis du vil gå tilbake til hovedmenyen
    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Me.Close()
        hovedSide.Show()
    End Sub

    Private Sub taptOrdet_Click(sender As Object, e As EventArgs) Handles taptOrdet.Click

    End Sub
End Class
