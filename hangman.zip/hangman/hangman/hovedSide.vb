﻿Public Class hovedSide
    'Her settes arrays med alle ordene som kan velges
    Public tilfeldig() = {"BATMAN", "TITANIC", "IRONMAN", "SUPERMAN", "ARQ", "godfather", "Belgia", "Frankrike", "Hellas", "Island", "Italia", "tyskland", "polen", "spania", "slovakia", "norge", "danmark", "sverige", "Alaska", "california", "florida", "illinois", "montana", "virginia", "colorado", "washington", "Gaupe", "Elg", "Ulv", "katt", "hund", "sel", "piggsvin", "spekkhogger", "isbjørn"}
    Public filmer() As String = {"BATMAN", "TITANIC", "IRONMAN", "SUPERMAN", "ARQ", "gudfaren"}
    Public landieuropa() As String = {"Belgia", "Frankrike", "Hellas", "Island", "Italia", "tyskland", "polen", "spania", "slovakia", "norge", "danmark", "sverige"}
    Public stateriusa() As String = {"Alaska", "california", "florida", "illinois", "montana", "virginia", "colorado", "washington"}
    Public dyr() As String = {"Gaupe", "Elg", "Ulv", "katt", "hund", "sel", "piggsvin", "spekkhogger", "isbjørn"}


    'brukes for å ha ordet i hangman.vb
    Public theWord

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Gjør bildet fullscreen og borderless 
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized

        'set bakgrunnsbilde
        Me.BackgroundImage = Image.FromFile("..\..\..\pages\hoved\hovedside\Resources\larry.jpg")

        'Sett valgmulighetene i comboboksen
        ComboBox1.Items.Add("Tilfeldig ord")
        ComboBox1.Items.Add("Filmer")
        ComboBox1.Items.Add("Land i Europa")
        ComboBox1.Items.Add("Stater i USA")
        ComboBox1.Items.Add("Dyr")
        ComboBox1.SelectedIndex = 0

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'når knappen trykkes nullstilles order som skal bli valgt, slik at vi kan spille flere ganger.
        theWord = ""

        'så velges et tilfeldig ord ut i fra hvilken kategori som blir valgt.
        'Formelen for rnd er (maxValue - min value + 1) * rnd() + min value.
        ' valgte å bruke use case
        Select Case ComboBox1.SelectedIndex
            Case 0

                theWord = tilfeldig(CInt(Math.Floor((tilfeldig.Length - 0 + 1) * Rnd())) + 0)
            Case 1
                theWord = filmer(CInt(Math.Floor((filmer.Length - 0 + 1) * Rnd())) + 0)
            Case 2
                theWord = landieuropa(CInt(Math.Floor((landieuropa.Length - 0 + 1) * Rnd())) + 0)
            Case 3
                theWord = stateriusa(CInt(Math.Floor((stateriusa.Length - 0 + 1) * Rnd())) + 0)
            Case 4
                theWord = dyr(CInt(Math.Floor((dyr.Length - 0 + 1) * Rnd())) + 0)
        End Select


        'Dette eksempelet ble valgt bort til fordel for use case som har lettere syntakse å lese
        'If ComboBox1.SelectedIndex = 0 Then
        '    theWord = tilfeldig(CInt(Math.Floor((tilfeldig.Length - 0 + 1) * Rnd())) + 0)
        'ElseIf ComboBox1.SelectedIndex = 1 Then
        '    theWord = filmer(CInt(Math.Floor((filmer.Length - 0 + 1) * Rnd())) + 0)
        'ElseIf ComboBox1.SelectedIndex = 2 Then
        '    theWord = landieuropa(CInt(Math.Floor((landieuropa.Length - 0 + 1) * Rnd())) + 0)
        'ElseIf ComboBox1.SelectedIndex = 3 Then
        '    theWord = stateriusa(CInt(Math.Floor((stateriusa.Length - 0 + 1) * Rnd())) + 0)
        'ElseIf ComboBox1.SelectedIndex = 4 Then
        '    theWord = dyr(CInt(Math.Floor((dyr.Length - 0 + 1) * Rnd())) + 0)
        'End If



        'gå til neste form, og avslutt denne formen
        hangman.Show()
        Me.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'asvlutt knapp som skrur av applikasjonen
        Application.Exit()
    End Sub
End Class
