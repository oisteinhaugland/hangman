﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class hangman
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.fyllBoks = New System.Windows.Forms.Button()
        Me.ordet = New System.Windows.Forms.Label()
        Me.streker = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.brukteBokstaver = New System.Windows.Forms.Label()
        Me.brukteBoks = New System.Windows.Forms.Button()
        Me.alfabetBoks = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.taptOrdet = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(917, 239)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(36, 27)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "A"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(917, 272)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(36, 27)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "F"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(917, 304)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(36, 27)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "K"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(917, 337)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(36, 27)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "P"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(917, 370)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(36, 27)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "U"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(917, 403)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(36, 27)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Z"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(959, 239)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(36, 27)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "B"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(959, 272)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(36, 27)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "G"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(959, 304)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(36, 27)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "L"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(959, 403)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(36, 27)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "Æ"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(959, 337)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(36, 27)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "Q"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(959, 370)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(36, 27)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "V"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(1001, 239)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(36, 27)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "C"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(1001, 272)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(36, 27)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "H"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(1001, 304)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(36, 27)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "M"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(1001, 337)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(36, 27)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "R"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(1001, 370)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(36, 27)
        Me.Button17.TabIndex = 16
        Me.Button17.Text = "W"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Location = New System.Drawing.Point(1001, 403)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(36, 27)
        Me.Button18.TabIndex = 17
        Me.Button18.Text = "Ø"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(1043, 239)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(36, 27)
        Me.Button19.TabIndex = 18
        Me.Button19.Text = "D"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Location = New System.Drawing.Point(1043, 272)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(36, 27)
        Me.Button20.TabIndex = 19
        Me.Button20.Text = "I"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Location = New System.Drawing.Point(1043, 304)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(36, 27)
        Me.Button21.TabIndex = 20
        Me.Button21.Text = "N"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Location = New System.Drawing.Point(1043, 337)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(36, 27)
        Me.Button22.TabIndex = 21
        Me.Button22.Text = "S"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.Location = New System.Drawing.Point(1043, 370)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(36, 27)
        Me.Button23.TabIndex = 22
        Me.Button23.Text = "X"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.Location = New System.Drawing.Point(1043, 403)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(36, 27)
        Me.Button24.TabIndex = 23
        Me.Button24.Text = "Å"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(1085, 239)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(36, 27)
        Me.Button25.TabIndex = 24
        Me.Button25.Text = "E"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.Location = New System.Drawing.Point(1085, 272)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(36, 27)
        Me.Button26.TabIndex = 25
        Me.Button26.Text = "J"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.Location = New System.Drawing.Point(1085, 304)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(36, 27)
        Me.Button27.TabIndex = 26
        Me.Button27.Text = "O"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.Location = New System.Drawing.Point(1085, 337)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(36, 27)
        Me.Button28.TabIndex = 27
        Me.Button28.Text = "T"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.Location = New System.Drawing.Point(1085, 370)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(36, 27)
        Me.Button29.TabIndex = 28
        Me.Button29.Text = "Y"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'fyllBoks
        '
        Me.fyllBoks.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fyllBoks.Location = New System.Drawing.Point(1085, 403)
        Me.fyllBoks.Name = "fyllBoks"
        Me.fyllBoks.Size = New System.Drawing.Size(36, 27)
        Me.fyllBoks.TabIndex = 29
        Me.fyllBoks.Text = "✓"
        Me.fyllBoks.UseVisualStyleBackColor = True
        '
        'ordet
        '
        Me.ordet.AutoSize = True
        Me.ordet.Font = New System.Drawing.Font("Courier New", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ordet.Location = New System.Drawing.Point(168, 482)
        Me.ordet.Margin = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.ordet.Name = "ordet"
        Me.ordet.Size = New System.Drawing.Size(146, 73)
        Me.ordet.TabIndex = 32
        Me.ordet.Text = "Ord"
        Me.ordet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'streker
        '
        Me.streker.AutoSize = True
        Me.streker.BackColor = System.Drawing.SystemColors.Control
        Me.streker.Font = New System.Drawing.Font("Courier New", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.streker.Location = New System.Drawing.Point(168, 521)
        Me.streker.Margin = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.streker.Name = "streker"
        Me.streker.Size = New System.Drawing.Size(146, 73)
        Me.streker.TabIndex = 33
        Me.streker.Text = "---"
        Me.streker.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Courier New", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(888, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(269, 30)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Brukte Bokstaver"
        '
        'brukteBokstaver
        '
        Me.brukteBokstaver.AutoSize = True
        Me.brukteBokstaver.BackColor = System.Drawing.SystemColors.Control
        Me.brukteBokstaver.Font = New System.Drawing.Font("Courier New", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.brukteBokstaver.Location = New System.Drawing.Point(872, 132)
        Me.brukteBokstaver.Name = "brukteBokstaver"
        Me.brukteBokstaver.Size = New System.Drawing.Size(96, 28)
        Me.brukteBokstaver.TabIndex = 36
        Me.brukteBokstaver.Text = "Brukte"
        '
        'brukteBoks
        '
        Me.brukteBoks.Location = New System.Drawing.Point(860, 100)
        Me.brukteBoks.Name = "brukteBoks"
        Me.brukteBoks.Size = New System.Drawing.Size(318, 96)
        Me.brukteBoks.TabIndex = 37
        Me.brukteBoks.UseVisualStyleBackColor = True
        '
        'alfabetBoks
        '
        Me.alfabetBoks.Location = New System.Drawing.Point(860, 202)
        Me.alfabetBoks.Name = "alfabetBoks"
        Me.alfabetBoks.Size = New System.Drawing.Size(318, 262)
        Me.alfabetBoks.TabIndex = 38
        Me.alfabetBoks.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(50, 20)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(711, 408)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 34
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button30.Font = New System.Drawing.Font("Courier New", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.Location = New System.Drawing.Point(906, 598)
        Me.Button30.Margin = New System.Windows.Forms.Padding(2)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(215, 62)
        Me.Button30.TabIndex = 39
        Me.Button30.Text = "Avslutt"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button31.Font = New System.Drawing.Font("Courier New", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.Location = New System.Drawing.Point(906, 521)
        Me.Button31.Margin = New System.Windows.Forms.Padding(2)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(215, 62)
        Me.Button31.TabIndex = 40
        Me.Button31.Text = "Hovedmeny"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'taptOrdet
        '
        Me.taptOrdet.AutoSize = True
        Me.taptOrdet.Font = New System.Drawing.Font("Courier New", 48.0!, System.Drawing.FontStyle.Bold)
        Me.taptOrdet.Location = New System.Drawing.Point(168, 603)
        Me.taptOrdet.Name = "taptOrdet"
        Me.taptOrdet.Size = New System.Drawing.Size(260, 73)
        Me.taptOrdet.TabIndex = 41
        Me.taptOrdet.Text = "Label1"
        '
        'hangman
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1284, 685)
        Me.Controls.Add(Me.taptOrdet)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.brukteBokstaver)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ordet)
        Me.Controls.Add(Me.streker)
        Me.Controls.Add(Me.fyllBoks)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.brukteBoks)
        Me.Controls.Add(Me.alfabetBoks)
        Me.Name = "hangman"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents fyllBoks As Button
    Friend WithEvents ordet As Label
    Friend WithEvents streker As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents brukteBokstaver As Label
    Public WithEvents brukteBoks As Button
    Friend WithEvents alfabetBoks As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents taptOrdet As Label
End Class
