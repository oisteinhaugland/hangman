﻿Public Class theEnd
    Private Sub theEnd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'borderless/fullscreen/bakgrunnsbilde
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.BackgroundImage = Image.FromFile("..\..\Resources\victory.jpg")

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'avslutte
        Application.Exit()
    End Sub

    'hovedmeny
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'Avslutt denne formen og gå til hovedside.
        Me.Close()
        hovedSide.Show()
    End Sub
End Class