﻿Public Class loss
    Private Sub loss_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'borderless, fullscreen, bakgrunnsbilde
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.BackgroundImage = Image.FromFile("..\..\Resources\tap.jpg")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'asvlutt denne siden og gå til hovedside.
        Me.Close()
        hovedSide.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'skru av applikasjonen
        Application.Exit()
    End Sub
End Class